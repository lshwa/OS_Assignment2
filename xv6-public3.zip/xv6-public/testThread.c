#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

lock_t* lk;

void printStatement(void* arg1, void* arg2) {
  int lock_ = *(int*)arg1;
  char ch_ = 'A' + (*(int*)arg2 - 1);
  if (lock_) lock_acquire(lk);
  printf(1, "This print statement is for printing %c.\n", ch_);
  for(int i=0;i<60;i++) {
    printf(1, "%c", ch_);
  }
  printf(1, "\n");
  sleep(10);
  if (lock_) lock_release(lk);
  exit();
}

int
main(int argc, char *argv[])
{
  int lock_;
  int ids[3] = {1, 2, 3};

  lock_init(lk);
  
  lock_ = 0;
  printf(1, "\n\n[ Without Lock: jarbled print statements ]\n");
  for (int i=0; i<3; i++){
    thread_create(&printStatement, (void *)&lock_, (void *)&ids[i]);
  }
  for (int i=3; i>0; i--){
    printf(1,"%d",i);
    thread_join();
  }

  lock_ = 1;
  printf(1, "\n\n[ With Lock: sequential print statements ]\n");
  for (int i=0; i<3; i++){
    thread_create(&printStatement, (void *)&lock_, (void *)&ids[i]);
  }
  for (int i=3; i>0; i--){
    thread_join();
  }
  
  exit();
}

