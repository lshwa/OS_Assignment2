#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"
#include "x86.h"
#include "mmu.h"

int thread_create(void (*start_routine)(void *, void *), void* arg1, void* arg2)
{
    void *stack;
    stack = malloc(PGSIZE);
    return clone(start_routine, arg1, arg2, stack);
}

int thread_join()
{
    void * stackPtr;
    int x = join(&stackPtr);
    return x;
}

int lock_init(lock_t *lk)
{
    lk->flag = 0;
    return 0;
}

void lock_acquire(lock_t *lk){
    while(xchg(&lk->flag, 1) != 0);
}

void lock_release(lock_t *lk){
    xchg(&lk->flag, 0);
}